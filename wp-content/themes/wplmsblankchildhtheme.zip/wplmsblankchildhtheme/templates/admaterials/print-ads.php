<?php

/**
 * Template Name: Print Ads
 * Template Post Type: page
 */

get_header('header.php');
require_once get_stylesheet_directory() . '/header-inner.php';
require_once get_stylesheet_directory() . '/templates/admaterials/top-navigation.php';
?>
</div>
<?php
get_footer('footer.php');
