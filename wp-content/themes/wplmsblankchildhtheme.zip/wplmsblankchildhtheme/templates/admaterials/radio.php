<?php
/**
 * Template Name: Radio Page
 * Template Post Type: page
 */

?>

<h1>It is my Radio Page </h1>