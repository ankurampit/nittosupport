<div class="container">
    <div class="tabs">
        <ul class="material-tabs">
            <li data-target="print-ads , radio">
                <a href="http://localhost/nittosupport/print-ads-page/">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link.png">
                    </i>
                    <span class="title">Print Ads</span>
                </a>
            </li>
            <li data-target="radio">
                <a href="http://localhost/nittosupport/radio-page/">
                    <i>
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link2.png">
                    </i>
                    <span class="title">Radio</span>
                </a>
            </li>

            <li class="tab-three">
                <a href="">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link3.png">
                    </i>
                    <span class="title">Nitto Logo</span>
                </a>
            </li>

            <li class="tab-four">
                <a href="">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link3.png">
                    </i>
                    <span class="title">Tire Photo</span>
                </a>
            </li>

            <li class="tab-five"> <a href="">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link3.png">
                    </i>
                    <span class="title">Television & Video</span>
                </a></li>

            <li class="tab-six">
                <a href="">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link3.png">
                    </i>
                    <span class="title">Web & Online</span>
                </a>
            </li>

            <li class="tab-seven"> <a href="">
                    <i><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/link3.png">
                    </i>
                    <span class="title">Vehicle Picture</span>
                </a></li>

        </ul>
    </div>
