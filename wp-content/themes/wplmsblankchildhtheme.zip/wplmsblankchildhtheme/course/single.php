<?php echo "<h1 style='color:red'>LOADED FROM CHILD THEME</h1>"; ?>
